<?php
require_once __DIR__ . '/config/database.php';
$services = $pdo->query("SELECT * FROM services WHERE status='active' ORDER BY name")->fetchAll();
$errors=[]; $success=false; $orderCode='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim($_POST['customer_name'] ?? '');
    $wa=trim($_POST['whatsapp'] ?? '');
    $address=trim($_POST['address'] ?? '');
    $serviceId=(int)($_POST['service_id'] ?? 0);
    $weight=(float)($_POST['weight'] ?? 0);
    $pickup=$_POST['pickup_method'] ?? '';

    if ($name==='') $errors[]='Nama wajib diisi.';
    if (!preg_match('/^[0-9+\-\s]{8,20}$/', $wa)) $errors[]='Nomor WhatsApp tidak valid.';
    if ($address==='') $errors[]='Alamat wajib diisi.';
    if ($serviceId<=0) $errors[]='Silakan pilih layanan.';
    if ($weight<=0 || $weight>500) $errors[]='Berat laundry harus lebih dari 0 dan maksimal 500 kg.';
    if (!in_array($pickup,['antar_sendiri','dijemput'],true)) $errors[]='Pilihan pengambilan tidak valid.';

    if (!$errors) {
        $check=$pdo->prepare("SELECT id FROM services WHERE id=? AND status='active'");
        $check->execute([$serviceId]);
        if (!$check->fetch()) $errors[]='Layanan tidak tersedia.';
    }
    if (!$errors) {
        do { $orderCode='CLN-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3))); 
             $q=$pdo->prepare("SELECT id FROM orders WHERE order_code=?"); $q->execute([$orderCode]);
        } while ($q->fetch());
        $stmt=$pdo->prepare("INSERT INTO orders(order_code,customer_name,whatsapp,address,service_id,weight,pickup_method,status) VALUES(?,?,?,?,?,?,?,'Menunggu')");
        $stmt->execute([$orderCode,$name,$wa,$address,$serviceId,$weight,$pickup]);
        $success=true;
    }
}
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pesan Laundry — CLEANOVA</title><link rel="stylesheet" href="assets/css/style.css">
</head><body>
<header class="navbar"><div class="container nav-inner"><a class="brand" href="index.php"><span>✦</span> CLEANOVA</a><nav><a href="index.php">Beranda</a><a href="index.php#layanan">Layanan</a></nav></div></header>
<main class="form-page"><div class="container narrow">
<?php if($success): ?>
<div class="success-card"><div class="success-icon">✓</div><span class="eyebrow">PESANAN BERHASIL</span><h1>Pesanan Anda sudah diterima.</h1><p>Simpan kode pesanan berikut untuk referensi.</p><div class="order-code"><?= htmlspecialchars($orderCode) ?></div><a class="btn primary" href="index.php">Kembali ke Beranda</a></div>
<?php else: ?>
<div class="form-intro"><span class="eyebrow">PEMESANAN</span><h1>Pesan laundry</h1><p>Isi data berikut dengan benar agar pesanan dapat diproses.</p></div>
<?php if($errors): ?><div class="alert"><?php foreach($errors as $e): ?><div>• <?= htmlspecialchars($e) ?></div><?php endforeach; ?></div><?php endif; ?>
<form method="post" class="form-card" novalidate>
<label>Nama Lengkap<input type="text" name="customer_name" maxlength="100" required value="<?= htmlspecialchars($_POST['customer_name']??'') ?>"></label>
<label>Nomor WhatsApp<input type="text" name="whatsapp" maxlength="20" placeholder="08xxxxxxxxxx" required value="<?= htmlspecialchars($_POST['whatsapp']??'') ?>"></label>
<label>Alamat<textarea name="address" maxlength="500" rows="3" required><?= htmlspecialchars($_POST['address']??'') ?></textarea></label>
<label>Jenis Layanan<select name="service_id" required><option value="">Pilih layanan</option><?php foreach($services as $s): ?><option value="<?= $s['id'] ?>" <?= (($_POST['service_id']??'')==$s['id'])?'selected':'' ?>><?= htmlspecialchars($s['name']) ?> — Rp<?= number_format($s['price'],0,',','.') ?>/<?= htmlspecialchars($s['unit']) ?></option><?php endforeach; ?></select></label>
<label>Berat Laundry (kg)<input type="number" name="weight" min="0.1" max="500" step="0.1" required value="<?= htmlspecialchars($_POST['weight']??'') ?>"></label>
<fieldset><legend>Metode Pengambilan</legend><label class="radio"><input type="radio" name="pickup_method" value="antar_sendiri" <?= (($_POST['pickup_method']??'')==='antar_sendiri')?'checked':'' ?>> Diantar sendiri</label><label class="radio"><input type="radio" name="pickup_method" value="dijemput" <?= (($_POST['pickup_method']??'')==='dijemput')?'checked':'' ?>> Dijemput</label></fieldset>
<button class="btn primary full" type="submit">Kirim Pesanan</button>
</form>
<?php endif; ?>
</div></main><footer><div class="container">© <?= date('Y') ?> CLEANOVA</div></footer></body></html>