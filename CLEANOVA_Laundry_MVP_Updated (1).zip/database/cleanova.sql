CREATE DATABASE IF NOT EXISTS cleanova CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cleanova;

CREATE TABLE services (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 description VARCHAR(255) NOT NULL,
 price DECIMAL(12,2) NOT NULL,
 unit VARCHAR(20) NOT NULL DEFAULT 'kg',
 status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_code VARCHAR(30) NOT NULL UNIQUE,
 customer_name VARCHAR(100) NOT NULL,
 whatsapp VARCHAR(20) NOT NULL,
 address VARCHAR(500) NOT NULL,
 service_id INT UNSIGNED NOT NULL,
 weight DECIMAL(8,2) NOT NULL,
 pickup_method ENUM('antar_sendiri','dijemput') NOT NULL,
 status ENUM('Pesanan Baru','Dikonfirmasi','Dijemput','Diproses','Siap Diantar','Selesai','Dibatalkan') NOT NULL DEFAULT 'Pesanan Baru',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_orders_service FOREIGN KEY(service_id) REFERENCES services(id)
) ENGINE=InnoDB;

INSERT INTO services(name,description,price,unit) VALUES
('Cuci + Setrika','Pakaian dicuci dan disetrika hingga siap digunakan.',7000,'kg'),
('Cuci Kering','Layanan pencucian dan pengeringan.',5000,'kg'),
('Setrika','Pakaian dirapikan dan disetrika.',4000,'kg');