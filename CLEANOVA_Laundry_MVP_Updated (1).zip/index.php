<?php
require_once __DIR__ . '/config/database.php';
$services = $pdo->query("SELECT * FROM services WHERE status = 'active' ORDER BY id ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CLEANOVA — Laundry Online</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="navbar">
  <div class="container nav-inner">
    <a class="brand" href="index.php"><span>✦</span> CLEANOVA</a>
    <nav>
      <a href="#layanan">Layanan</a>
      <a href="#cara">Cara Pesan</a>
      <a href="#kontak">Kontak</a>
      <a class="nav-btn" href="order.php">Pesan Sekarang</a>
    </nav>
  </div>
</header>

<main>
<section class="hero">
  <div class="container hero-grid">
    <div>
      <div class="eyebrow">LAUNDRY ONLINE • PRAKTIS</div>
      <h1>Urusan laundry jadi <em>lebih mudah.</em></h1>
      <p>CLEANOVA membantu Anda memesan layanan laundry secara online dengan proses yang sederhana, cepat, dan nyaman.</p>
      <div class="hero-actions">
        <a class="btn primary" href="order.php">Pesan Laundry</a>
        <a class="btn secondary" href="#layanan">Lihat Layanan</a>
      </div>
    </div>
    <div class="hero-card">
      <div class="bubble">✦</div>
      <div class="hero-card-content">
        <small>CLEANOVA SERVICE</small>
        <strong>Bersih. Rapi. Siap Dipakai.</strong>
        <p>Pesan dari rumah, kami bantu urus laundry Anda.</p>
      </div>
      <div class="mini-row"><span>✓ Mudah dipesan</span><span>✓ Praktis</span></div>
    </div>
  </div>
</section>

<section id="layanan" class="section">
  <div class="container">
    <div class="section-head">
      <div><span class="eyebrow">LAYANAN</span><h2>Pilih layanan sesuai kebutuhan</h2></div>
      <a href="order.php" class="text-link">Pesan sekarang →</a>
    </div>
    <div class="cards">
      <?php foreach ($services as $service): ?>
      <article class="service-card">
        <div class="service-icon">✧</div>
        <h3><?= htmlspecialchars($service['name']) ?></h3>
        <p><?= htmlspecialchars($service['description']) ?></p>
        <strong>Rp<?= number_format($service['price'],0,',','.') ?><small>/<?= htmlspecialchars($service['unit']) ?></small></strong>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="cara" class="section soft">
  <div class="container">
    <div class="center-head"><span class="eyebrow">CARA PESAN</span><h2>Hanya beberapa langkah</h2></div>
    <div class="steps">
      <div><span>01</span><h3>Pilih layanan</h3><p>Lihat layanan dan harga yang tersedia.</p></div>
      <div><span>02</span><h3>Isi data</h3><p>Masukkan nama, WhatsApp, alamat, dan detail laundry.</p></div>
      <div><span>03</span><h3>Kirim pesanan</h3><p>Pesanan tersimpan dan dapat diproses oleh admin.</p></div>
    </div>
  </div>
</section>

<section id="kontak" class="section">
  <div class="container contact-box">
    <div><span class="eyebrow">KONTAK</span><h2>Butuh bantuan?</h2><p>Hubungi CLEANOVA untuk informasi layanan dan pemesanan.</p></div>
    <div class="contact-info"><div><small>WhatsApp</small><strong>08xx-xxxx-xxxx</strong></div><div><small>Jam Operasional</small><strong>08.00–20.00</strong></div></div>
  </div>
</section>
</main>
<footer><div class="container">© <?= date('Y') ?> CLEANOVA. Laundry online yang praktis.</div></footer>
</body>
</html>